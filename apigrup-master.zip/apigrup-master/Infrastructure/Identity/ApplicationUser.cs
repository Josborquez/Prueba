﻿using Microsoft.AspNetCore.Identity;

namespace ApiGrup.Infrastructure.Identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}
