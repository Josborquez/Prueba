﻿namespace ApiGrup.Infrastructure.Options
{
    public class PasswordOptions
    {
        public int SaltSize { get; set; }
        public int KeySize { get; set; }
        public int Iteractions { get; set; }
    }
}
